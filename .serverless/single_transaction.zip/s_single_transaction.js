var serverlessSDK = require('./serverless_sdk/index.js')
serverlessSDK = new serverlessSDK({
tenantId: 'robertbuna',
applicationName: 'budget-app-app',
appUid: 'MvbYgCk7WVsXHytgSY',
tenantUid: 'p9q58CpS1rWGh5yxnP',
deploymentUid: 'd203e3de-e13d-432e-8ea4-4d33221bc5d2',
serviceName: 'budget-app',
stageName: 'prod',
pluginVersion: '3.1.2'})
const handlerWrapperArgs = { functionName: 'budget-app-prod-single_transaction', timeout: 6}
try {
  const userHandler = require('./single_transaction.js')
  module.exports.handler = serverlessSDK.handler(userHandler.main, handlerWrapperArgs)
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs)
}
